# Multi-seed robustness (2026-07-01 11:49)

Seeds/replicates: [42, 123, 2024]  |  samples: all 164

## gpt-4o (azure) — 3 replicates
| Condition | Mean Pass@1 | SD | 95% CI |
|---|---|---|---|
| TCGP | 81.9% | 1.3 pp | [80.5%, 83.3%] |
| CoT | 86.2% | 2.0 pp | [84.0%, 88.4%] |
| Direct | 85.8% | 0.9 pp | [84.7%, 86.8%] |

**TCGP − CoT margin:** -4.3 pp (95% CI [-5.6, -2.9] pp) → **robust (CI excludes 0)**

## gpt-4.1 (azure) — 3 replicates
| Condition | Mean Pass@1 | SD | 95% CI |
|---|---|---|---|
| TCGP | 87.0% | 1.8 pp | [85.0%, 89.0%] |
| CoT | 91.7% | 0.7 pp | [90.9%, 92.5%] |
| Direct | 88.6% | 0.4 pp | [88.2%, 89.0%] |

**TCGP − CoT margin:** -4.7 pp (95% CI [-6.4, -2.9] pp) → **robust (CI excludes 0)**

## gpt-35-turbo (azure_models) — 3 replicates
| Condition | Mean Pass@1 | SD | 95% CI |
|---|---|---|---|
| TCGP | 0.0% | 0.0 pp | [0.0%, 0.0%] |
| CoT | 0.0% | 0.0 pp | [0.0%, 0.0%] |
| Direct | 0.0% | 0.0 pp | [0.0%, 0.0%] |

**TCGP − CoT margin:** +0.0 pp (95% CI [+0.0, +0.0] pp) → **NOT robust (CI crosses 0)**

## gpt-5.3-codex (azure_responses) — 3 replicates
| Condition | Mean Pass@1 | SD | 95% CI |
|---|---|---|---|
| TCGP | 0.0% | 0.0 pp | [0.0%, 0.0%] |
| CoT | 0.0% | 0.0 pp | [0.0%, 0.0%] |
| Direct | 0.0% | 0.0 pp | [0.0%, 0.0%] |

**TCGP − CoT margin:** +0.0 pp (95% CI [+0.0, +0.0] pp) → **NOT robust (CI crosses 0)**

## codex-mini (azure_responses) — 3 replicates
| Condition | Mean Pass@1 | SD | 95% CI |
|---|---|---|---|
| TCGP | 0.0% | 0.0 pp | [0.0%, 0.0%] |
| CoT | 0.0% | 0.0 pp | [0.0%, 0.0%] |
| Direct | 0.0% | 0.0 pp | [0.0%, 0.0%] |

**TCGP − CoT margin:** +0.0 pp (95% CI [+0.0, +0.0] pp) → **NOT robust (CI crosses 0)**

## Llama-3.3-70B-Instruct (azure_models) — 3 replicates
| Condition | Mean Pass@1 | SD | 95% CI |
|---|---|---|---|
| TCGP | 0.0% | 0.0 pp | [0.0%, 0.0%] |
| CoT | 0.0% | 0.0 pp | [0.0%, 0.0%] |
| Direct | 0.0% | 0.0 pp | [0.0%, 0.0%] |

**TCGP − CoT margin:** +0.0 pp (95% CI [+0.0, +0.0] pp) → **NOT robust (CI crosses 0)**

## gemini-2.5-flash (gemini) — 3 replicates
| Condition | Mean Pass@1 | SD | 95% CI |
|---|---|---|---|
| TCGP | 21.7% | 3.7 pp | [17.5%, 26.0%] |
| CoT | 10.0% | 0.9 pp | [8.9%, 11.0%] |
| Direct | 16.3% | 0.7 pp | [15.5%, 17.1%] |

**TCGP − CoT margin:** +11.8 pp (95% CI [+6.5, +17.1] pp) → **robust (CI excludes 0)**

